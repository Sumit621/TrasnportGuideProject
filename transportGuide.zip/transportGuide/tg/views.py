from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from jinja2.runtime import Context
from tg.models import BusRoutes, PoribohonRoutes
from tg.models import UserPrefHist,PlaceLocs,HubLocs
import folium

#functions

def Djik3node(request):
    if request.method=="POST":
        start=request.POST.get("start")
        dest=request.POST.get("dest")
        via=request.POST.get("via")
        graph={}
        dataSet=BusRoutes.objects.all()
        for item in dataSet:
            rBus=item.values.split(",")
            dictVal=[]
            for j in rBus:
                tup=tuple(j.split("_"))
                dictVal.append(tup)
            graph[item.place]=dictVal

        if start not in graph.keys():
            return HttpResponse("<h1>Starting Point not Identified!</h1>")
        
        queue=[[start]]
        visited=[]

        if start == via:
            return HttpResponse("<h1>You are already at your Via!</h1>")

        half_paths=[]
        new_path=[]
        flag=True
        path=queue.pop(0)
        node=path[-1]
        if node not in visited:
            adjacent=graph[node]
            for i in adjacent:
                new_path=list(path)
                new_path.append(i)
                if i[0] == via:
                    half_paths.append(new_path)
                    flag=False
                    continue
                queue.append(new_path)
        visited.append(node)

        while queue:
            path=queue.pop(0)
            node=path[-1]
            if node[0] not in visited:
                adjacent=graph[node[0]]
                for i in adjacent:
                    new_path=list(path)
                    new_path.append(i)
                    if i[0] == via:
                        half_paths.append(new_path)
                        flag=False
                        continue
                        # return HttpResponse("<h1>{}</h1>".format(new_path))
                    queue.append(new_path)
            visited.append(node[0])
            # if node == dest:
            #      return HttpResponse("<h1>new_path</h1>")
        
        if flag==True:
            return HttpResponse("<h1>There is no required Bus Route</h1>")

        queue=[[via]]
        visited=[]

        if via == dest:
            return HttpResponse("<h1>You are already at your Destination!</h1>")

        half_paths2=[]
        new_path2=[]
        flag=True
        path=queue.pop(0)
        node=path[-1]
        if node not in visited:
            adjacent=graph[node]
            for i in adjacent:
                new_path2=list(path)
                new_path2.append(i)
                if i[0] == dest:
                    new_path2.pop(0)
                    half_paths2.append(new_path2)
                    flag=False
                    continue
                queue.append(new_path2)
        visited.append(node)

        while queue:
            path=queue.pop(0)
            node=path[-1]
            if node[0] not in visited:
                adjacent=graph[node[0]]
                for i in adjacent:
                    new_path2=list(path)
                    new_path2.append(i)
                    if i[0] == dest:
                        new_path2.pop(0)
                        half_paths2.append(new_path2)
                        flag=False
                        continue
                        # return HttpResponse("<h1>{}</h1>".format(new_path))
                    queue.append(new_path2)
            visited.append(node[0])
            # if node == dest:
            #      return HttpResponse("<h1>new_path</h1>")
        if flag==True:
            return "There is no required Bus Route<"
        txtList=[]
        pathNo=1
        for i in half_paths:
            for j in half_paths2:
                final_path=i+j
                txt=""
                txt=txt+str(pathNo)+') '
                for it in range(1,len(final_path)-1):
                    if final_path[it][1]!=final_path[it+1][1]:
                            txt=txt+"Go upto "+final_path[it][0]+" in "+final_path[it][1]+". "
                txt=txt+"Go upto "+final_path[-1][0]+" in "+final_path[-1][1]+"."
                txtList.append(txt)
                pathNo+=1
                print(txt)
                print(final_path)
        return txtList


def getCNGviaFare(request):
    if request.method=="POST":
        start=request.POST.get("start")
        dest=request.POST.get("dest")
        via=request.POST.get("via")
        graph={}
        dataSet=BusRoutes.objects.all()
        for item in dataSet:
            rRoads=item.roads.split(",")
            graph[item.place]=rRoads

        if start not in graph.keys():
            return HttpResponse("<h1>Starting Point not Identified!</h1>")
        
        queue=[[start]]
        visited=[]

        if start == via:
            return HttpResponse("<h1>You are already at your Via!</h1>")

        new_path=[]
        flag=True
        path=queue.pop(0)
        node=path[-1]
        if node not in visited:
            adjacent=graph[node]
            for i in adjacent:
                new_path=list(path)
                new_path.append(i)
                queue.append(new_path)
                if i == via:
                    flag=False
                    break
        visited.append(node)

        while queue and flag==True:
            path=queue.pop(0)
            node=path[-1]
            if node not in visited and flag==True:
                adjacent=graph[node]
                for i in adjacent:
                    new_path=list(path)
                    new_path.append(i)
                    queue.append(new_path)
                    if i == via:
                        flag=False
                        break
                        # return HttpResponse("<h1>{}</h1>".format(new_path))
            visited.append(node[0])
            # if node == dest:
            #      return HttpResponse("<h1>new_path</h1>")
        
        if flag==True:
            return HttpResponse("<h1>There is no required Road Route</h1>")

        queue=[[via]]
        visited=[]

        if via == dest:
            return HttpResponse("<h1>You are already at your Destination!</h1>")

        new_path2=[]
        flag=True
        path=queue.pop(0)
        node=path[-1]
        if node not in visited:
            adjacent=graph[node]
            for i in adjacent:
                new_path2=list(path)
                new_path2.append(i)
                queue.append(new_path2)
                if i == dest:
                    new_path2.pop(0)
                    flag=False
                    break
        visited.append(node)

        while queue and flag==True:
            path=queue.pop(0)
            node=path[-1]
            if node[0] not in visited and flag==True:
                adjacent=graph[node]
                for i in adjacent:
                    new_path2=list(path)
                    new_path2.append(i)
                    queue.append(new_path2)
                    if i == dest:
                        new_path2.pop(0)
                        flag=False
                        break
                        # return HttpResponse("<h1>{}</h1>".format(new_path))
            visited.append(node[0])
            # if node == dest:
            #      return HttpResponse("<h1>new_path</h1>")
        if flag==True:
            return "There is no required Road Route"
        final_path=new_path+new_path2
        dist=len(final_path)
        fare=FareCalc(dist)
        msg='You will have to pay around '+fare
        return msg


def showMap(request):
    if request.method=="POST":
        startText=request.POST.get("start")
        destText=request.POST.get("dest")
        start=BusRoutes.objects.get(place=startText)
        dest=BusRoutes.objects.get(place=destText)
        A_lat=start.geoLocLat
        A_lon=start.geoLocLon
        pointA=(A_lat,A_lon)
        B_lat=dest.geoLocLat
        B_lon=dest.geoLocLon
        pointB=(B_lat,B_lon)
        m=folium.Map(width='100%',height='100%',location=getCenter(A_lat,A_lon,B_lat,B_lon),zoom_start=12.4)
        folium.Marker([A_lat,A_lon],tooltip='Click for details',popup=start.place,
                    icon=folium.Icon(color='blue')).add_to(m)
        
        folium.Marker([B_lat,B_lon],tooltip='Click for details',popup=dest.place,
                    icon=folium.Icon(color='red', icon='cloud')).add_to(m)
        m=m._repr_html_()
        return m

def getCenter(latA,lonA,latB=None,lonB=None):
    cord=(latA,lonA)
    if latB:
        cord=[(latA+latB)/2,(lonA+lonB)/2]
    return cord

def FareCalc(num):
    if num<3:
        return 'Tk.120'
    elif num>=3 and num<5:
        return 'Tk.150'
    elif num>=5 and num<7:
        return 'Tk.200'
    elif num>=8 and num<10:
        return 'Tk.250'
    elif num>=10 and num<13:
        return 'Tk.300'
    elif num>=13 and num<15:
        return 'Tk.350'
    elif num>=15 and num<17:
        return 'Tk.400'
    elif num>=17:
        return 'Tk.500'

def getCNGfare(request):
    if request.method=="POST":
        start=request.POST.get("start")
        dest=request.POST.get("dest")
        graph={}
        dataSet=BusRoutes.objects.all()
        for item in dataSet:
            rRoads=item.roads.split(",")
            graph[item.place]=rRoads
        if start not in graph.keys():
            return "Starting Point not Identified!"
        queue=[[start]]
        visited=[]

        if start == dest:
            return "You are already at your Destination!"

        path=queue.pop(0)
        node=path[-1]
        if node not in visited:
            adjacent=graph[node]
            for i in adjacent:
                new_path=list(path)
                new_path.append(i)
                queue.append(new_path)
                if i == dest:
                    dist=len(new_path)
                    fare=FareCalc(dist)
                    msg='You will have to pay around '+fare
                    return msg
        visited.append(node)

        while queue:
            path=queue.pop(0)
            node=path[-1]
            if node not in visited:
                adjacent=graph[node]
                for i in adjacent:
                    new_path=list(path)
                    new_path.append(i)
                    queue.append(new_path)
                    if i == dest:
                        dist=len(new_path)
                        fare=FareCalc(dist)
                        msg='You will have to pay around '+fare
                        return msg
                        # return HttpResponse("<h1>{}</h1>".format(new_path))
            visited.append(node)
            # if node == dest:
            #      return HttpResponse("<h1>new_path</h1>")
        return "There is no required Road Route"

def addHistory(uName,start,dest):
    user=UserPrefHist.objects.get(UserName=uName)
    newRec=start+' to '+dest
    histList=user.history.split(",")

    if len(histList)==5:
        histList.pop()
        histList.insert(0,newRec)
    else:
        histList.insert(0,newRec)
    data=","
    data=data.join(histList)
    user.history=data
    user.save()

def addHistory3(uName,start,via,dest):
    user=UserPrefHist.objects.get(UserName=uName)
    newRec=start+' to '+dest+' via '+via
    histList=user.history.split(",")

    if len(histList)==5:
        histList.pop()
        histList.insert(0,newRec)
    else:
        histList.insert(0,newRec)
    data=","
    data=data.join(histList)
    user.history=data
    user.save()

def addPref(uName,start,dest):
    user=UserPrefHist.objects.get(UserName=uName)
    newRec=start+' to '+dest
    if user.preferredRoutes=="":
        user.preferredRoutes=newRec
    else:
        user.preferredRoutes=user.preferredRoutes+','+newRec
    user.save()

def delPref(uName,start,dest):
    user=UserPrefHist.objects.get(UserName=uName)
    delRec=start+' to '+dest
    prefList=user.preferredRoutes.split(",")
    i=0
    flag=False
    for rec in prefList:
        if rec==delRec:
            flag=True
            prefList.pop(i)
            break
        i+=1
    # if flag==False:
    #     print('Preferred Route does not exist')
    data=","
    data=data.join(prefList)
    user.preferredRoutes=data
    user.save()



# Create your views here. The End of User Defined Ultility Functions and Start of Functions to handle page requests.

def index(request):
    if request.user.is_anonymous:
        return redirect("/login")
    if request.method=="POST":
        start=request.POST.get("start")
        dest=request.POST.get("dest")
        addHistory(request.user.username,start,dest)
        graph={}
        dataSet=BusRoutes.objects.all()
        for item in dataSet:
            rBus=item.values.split(",")
            dictVal=[]
            for j in rBus:
                tup=tuple(j.split("_"))
                dictVal.append(tup)
            graph[item.place]=dictVal

        if start not in graph.keys():
            return HttpResponse("<h1>Starting Point not Identified!</h1>")
        queue=[[start]]
        visited=[]

        if start == dest:
            return HttpResponse("<h1>You are already at your Destination!</h1>")

        startObj=BusRoutes.objects.get(place=start)
        destObj=BusRoutes.objects.get(place=dest)
        A_lat=startObj.geoLocLat
        A_lon=startObj.geoLocLon
        pointA=(A_lat,A_lon)
        B_lat=destObj.geoLocLat
        B_lon=destObj.geoLocLon
        pointB=(B_lat,B_lon)
        m=folium.Map(width='100%',height='100%',location=getCenter(A_lat,A_lon,B_lat,B_lon),zoom_start=12.4)
        folium.Marker([A_lat,A_lon],tooltip='Click for details',popup=startObj.place,
                    icon=folium.Icon(color='blue')).add_to(m)
        
        folium.Marker([B_lat,B_lon],tooltip='Click for details',popup=destObj.place,
                    icon=folium.Icon(color='red', icon='cloud')).add_to(m)
        
        m=m._repr_html_()

        txtList=[]
        pathNo=1
        busFound=False
        cngFound=False
        path=queue.pop(0)
        node=path[-1]
        if node not in visited:
            adjacent=graph[node]
            for i in adjacent:
                new_path=list(path)
                new_path.append(i)
                if i[0] == dest:
                    busFound=True
                    txt=""
                    txt=txt+str(pathNo)+") Go upto "+new_path[-1][0]+" in "+new_path[-1][1]+"."
                    txtList.append(txt)
                    if cngFound==False:
                        cngFound=True
                        msgCNG=getCNGfare(request)
                    pathNo+=1
                    continue
                    
                queue.append(new_path)
        visited.append(node)

        while queue:
            path=queue.pop(0)
            node=path[-1]
            # print('-----nodes-----')
            # print(node)
            if node[0] not in visited:
                adjacent=graph[node[0]]
                for i in adjacent:
                    new_path=list(path)
                    new_path.append(i)
                    if i[0] == dest:
                        busFound=True
                        txt=""
                        txt=txt+str(pathNo)+') '
                        for it in range(1,len(new_path)-1):
                            # print('-----Tuples-------')
                            # print(new_path[it])
                            if new_path[it][1]!=new_path[it+1][1]:
                                    txt=txt+"Go upto "+new_path[it][0]+" in "+new_path[it][1]+". "
                        txt=txt+"Go upto "+new_path[-1][0]+" in "+new_path[-1][1]+"."
                        txtList.append(txt)
                        print(txt)
                        if cngFound==False:
                            cngFound=True
                            msgCNG=getCNGfare(request)
                        pathNo+=1
                        continue
    
                    queue.append(new_path)
                        # return HttpResponse("<h1>{}</h1>".format(new_path))
            visited.append(node[0])
            # if node == dest:
            #      return HttpResponse("<h1>new_path</h1>")
        if busFound==True:
            context={
                    'msg':txtList,
                    'msg2':msgCNG,
                    'map':m,
                    }
            return viewRoute2(request,context)
            
        return HttpResponse("<h1>There is no required Bus Route</h1>")
    
    return render(request,"index.html")

def viaPlace(request):
    if request.method=="POST":
        msgBus=Djik3node(request)
        msgCNG=getCNGviaFare(request)
        m=showMap(request)
        start=request.POST.get("start")
        via=request.POST.get("via")
        dest=request.POST.get("dest")
        addHistory3(request.user.username,start,via,dest)
        context={
                'msg':msgBus,
                'msg2':msgCNG,
                'map':m,
            }
        return render(request,'viewRoute.html',context)
    return render(request,'viaPlace.html')

def loginUser(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("/")
        # A backend authenticated the credentials
        else:
         # No backend authenticated the credentials
            messages.error(request,'username or password not correct')
            return render(request,"login.html")

    return render(request,"login.html")

def logoutUser(request):
    logout(request)
    return redirect("/login")

def signupUser(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        eMail=request.POST.get("email")
        Fname=request.POST.get("firstname")
        Lname=request.POST.get("lastname")
        user = User.objects.create_user(username, eMail, password)
        user.first_name=Fname
        user.last_name=Lname
        userPrfs=UserPrefHist(UserName=username,preferredRoutes="",history="")
        user.save()
        userPrfs.save()
        login(request, user)
        return redirect("/")
    return render(request,"signup.html")

def viewRoute2(request,context):
    return render(request,'viewRoute.html',context)

def viewRoute(request):
    return render(request,'viewRoute.html')

class histElem:
    start="-"
    end="-"
    via="-"

def viewHistory(request):
    uName=request.user.username
    userData=UserPrefHist.objects.get(UserName=uName)
    hist=userData.history
    histElemList=[]
    histList=hist.split(',')
    for i in histList:
        temp=histElem()
        startDest=i.split(' to ')
        destVia=startDest[1].split(' via ')
        temp.start=startDest[0]
        temp.end=destVia[0]
        if len(destVia)==2:
            temp.via=destVia[1]
        histElemList.append(temp)

    context={
        'name':uName,
        'msg':histElemList,
    }
    return render(request,'viewHistory.html',context)

def viewPoribohon(request):
    if request.method=="POST":
        busName=request.POST.get("busname")
        if PoribohonRoutes.objects.filter(poribohonName=busName).exists():
            poribohon=PoribohonRoutes.objects.get(poribohonName=busName)
            route=poribohon.fullRoute
            routeList=route.split(',')
            context={
                'name':busName,
                'route':routeList,
            }
        else:
            context={
                'name':"Unknown",
                'route':0,
            }
        return render(request,'viewPoribohon.html',context)
    return render(request,'viewPoribohon.html')

class prefObj:
    start=None
    end=None

def modPrefs(request):
    if request.method=="POST" and 'addBtn' in request.POST:
        start=request.POST.get("start")
        dest=request.POST.get("dest")
        uName=request.user.username
        addPref(uName,start,dest)
        uRow=UserPrefHist.objects.get(UserName=uName)
        prefRoutes=uRow.preferredRoutes
        prefObjList=[]
        prefList=prefRoutes.split(',')
        for i in prefList:
            tp=prefObj()
            startDest=i.split(' to ')
            tp.start=startDest[0]
            tp.end=startDest[1]
            prefObjList.append(tp)
        context={
            'name':uName,
            'route':prefObjList,
        }
        return render(request,'modPrefs.html',context)
    elif request.method=="POST" and 'delBtn' in request.POST:
        start=request.POST.get("start")
        dest=request.POST.get("dest")
        uName=request.user.username
        delPref(uName,start,dest)
        uRow=UserPrefHist.objects.get(UserName=uName)
        prefRoutes=uRow.preferredRoutes
        if prefRoutes!="":
            prefObjList=[]
            prefList=prefRoutes.split(',')
            for i in prefList:
                tp=prefObj()
                startDest=i.split(' to ')
                tp.start=startDest[0]
                tp.end=startDest[1]
                prefObjList.append(tp)
            context={
                'name':uName,
                'route':prefObjList,
            }
        else:
            context={
                'name':uName,
                'route':0,
            }
        return render(request,'modPrefs.html',context)
    uName=request.user.username
    uRow=UserPrefHist.objects.get(UserName=uName)
    prefRoutes=uRow.preferredRoutes
    if prefRoutes!="":
        prefObjList=[]
        prefList=prefRoutes.split(',')
        for i in prefList:
            tp=prefObj()
            startDest=i.split(' to ')
            tp.start=startDest[0]
            tp.end=startDest[1]
            prefObjList.append(tp)
        context={
            'name':uName,
            'route':prefObjList,
        }
    else:
        context={
            'name':uName,
            'route':0,
        }
    return render(request,'modPrefs.html',context)

def showMapSingle(lat,lon):
    point=(lat,lon)
    m=folium.Map(width='100%',height='100%',location=[lat,lon],zoom_start=16)
    folium.Marker([lat,lon],tooltip='Click for details',popup="Hub",
                icon=folium.Icon(color='blue')).add_to(m)
    
    m=m._repr_html_()
    return m

def nearestHub(request):
    m=folium.Map(width='100%',height='100%',location=[23.779533,90.398828],zoom_start=16)
    m=m._repr_html_()
    placeTxt=""
    if request.method=="POST":
        uName=request.user.username
        locat=request.POST.get("locat")
        nrst=""
        place=""
        place=PlaceLocs.objects.get(placeName=locat)
        if place!="" or place!=None:
            placeLat=place.geoLocLat
            placeLon=place.geoLocLon
            minDist=9999
            hubs=HubLocs.objects.all()
            for i in hubs:
                hubLat=i.geoLocLat
                hubLon=i.geoLocLon
                dist=((hubLat-placeLat)*(hubLat-placeLat))+((hubLon-placeLon)*(hubLon-placeLon))
                if dist<minDist:
                    minDist=dist
                    nrst=i
            m=showMapSingle(nrst.geoLocLat,nrst.geoLocLon)
            placeTxt="Nearest hub is "+nrst.hubName
            
        else:
            m=folium.Map(width='100%',height='100%',location=[23.779533,90.398828],zoom_start=15)
            m=m._repr_html_()
    context={'place':placeTxt,
             'map':m,
             }
    return render(request,'nearestHub.html',context)






        
    





        
