from django.contrib import admin
from django.urls import path, include
from tg import views

urlpatterns = [
    path('',views.index,name="index"),
    path('index',views.index,name="index"),
    path('login',views.loginUser,name="login"),
    path('logout',views.logoutUser,name="logout"),
    path('signup',views.signupUser,name="signup"),
    path('viewRoute',views.viewRoute,name="viewRoute"),
    path('viaPlace',views.viaPlace,name="viaPlace"),
    path('viewHistory',views.viewHistory,name="viewHistory"),
    path('viewPoribohon',views.viewPoribohon,name="viewPoribohon"),
    path('modPrefs',views.modPrefs,name="modPrefs"),
    path('nearestHub',views.nearestHub,name="nearestHub"),
]