from django.db import models


# Create your models here.

class BusRoutes(models.Model):
    place=models.CharField(max_length=250)
    values=models.TextField()
    roads=models.TextField()
    geoLocLat=models.FloatField()
    geoLocLon=models.FloatField()

class UserPrefHist(models.Model):
    UserName=models.CharField(max_length=250)
    preferredRoutes=models.TextField()
    history=models.TextField()

class PoribohonRoutes(models.Model):
    poribohonName=models.CharField(max_length=250)
    fullRoute=models.TextField()

class PlaceLocs(models.Model):
    placeName=models.CharField(max_length=250)
    geoLocLat=models.FloatField()
    geoLocLon=models.FloatField()

class HubLocs(models.Model):
    hubName=models.CharField(max_length=250)
    geoLocLat=models.FloatField()
    geoLocLon=models.FloatField()




