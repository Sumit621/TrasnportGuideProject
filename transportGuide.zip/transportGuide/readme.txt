****** Where to? / Jaba Koi? (A Transportation Guide to Dhaka)******

Previously Implemented Features:
i)Login and Signup pages.
ii)Bus Routes for a given Starting and Destination.
iii)Front-End Design Layout using CSS:Bootsrap.

New Features:
i)Map integration to show the route.
ii)Information about CNG fares.
iii)Bus Routes through specified via locations.
iv)Updated CNG Routes through specified via locations.
v)Information about the Full Routes of Bus Poribohons.
vi)User's ability to add or delete Preferred Routes.
vii)User's ability to view history of last 5 enquiries. 